'use strict';
const $ = id => document.getElementById(id);
let analyzed = null;
let timer = null;
function setBusy(busy) { $('analyzeBtn').disabled = busy; $('analyzeBtn').innerHTML = busy ? 'Analisando vídeo...' : 'Analisar vídeo <span>→</span>'; }
function alertMsg(message) { $('alert').textContent = message; $('alert').classList.remove('hidden'); }
function clearMsg() { $('alert').classList.add('hidden'); }
function fmtTime(seconds) { if (typeof seconds !== 'number') return 'Duração indisponível'; const h=Math.floor(seconds/3600),m=Math.floor(seconds%3600/60),s=Math.floor(seconds%60); return (h ? h+':' + String(m).padStart(2,'0') : m)+':'+String(s).padStart(2,'0'); }
async function api(path, options) { let res; try {res=await fetch(path, options);}catch(e){throw Error('Não foi possível acessar o servidor local. Confirme que a janela do aplicativo está aberta.');} let obj;try{obj=await res.json();}catch(e){throw Error('O servidor retornou uma resposta inesperada.');} if (!res.ok) throw Error(typeof obj.detail==='string'?obj.detail:'Falha no processamento.');return obj;}
$('paste').addEventListener('click',async()=>{try{$('url').value=await navigator.clipboard.readText();$('url').focus();}catch(e){alertMsg('Não foi possível acessar a área de transferência. Use Ctrl+V.');}});
$('url').addEventListener('input',()=>{ analyzed=null; $('videoCard').hidden=true; $('progressCard').hidden=true; $('authorized').checked=false; $('downloadBtn').disabled=true; clearMsg(); if(timer) clearInterval(timer); });
$('analyzeForm').addEventListener('submit',async e=>{e.preventDefault();clearMsg();setBusy(true);$('videoCard').hidden=true;$('progressCard').hidden=true;if(timer) clearInterval(timer);try{analyzed=await api('/api/analyze',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({url:$('url').value})});$('videoTitle').textContent=analyzed.title;$('videoUploader').textContent=analyzed.uploader || 'Canal não informado';$('duration').textContent='Duração: '+fmtTime(analyzed.duration);$('thumb').src=analyzed.thumbnail || ''; $('videoCard').hidden=false; $('authorized').checked=false;$('downloadBtn').disabled=true;}catch(err){alertMsg(err.message);}finally{setBusy(false);}});
function selectedFormat(){return document.querySelector('input[name="format"]:checked').value;}
document.querySelectorAll('input[name="format"]').forEach(r=>r.addEventListener('change',()=>{document.querySelectorAll('.format').forEach(x=>x.classList.toggle('chosen',x.querySelector('input').checked));$('qualityWrap').hidden=selectedFormat()==='mp3';}));
$('authorized').addEventListener('change',()=>{$('downloadBtn').disabled=!$('authorized').checked || !analyzed;});
$('downloadBtn').addEventListener('click',async()=>{if(!analyzed || !$('authorized').checked)return;clearMsg();$('downloadBtn').disabled=true;$('progressCard').hidden=false;$('saveBtn').classList.add('hidden');$('jobMessage').textContent='Enviando tarefa...';$('percent').textContent='0%';$('progressFill').style.width='0%';try{const job=await api('/api/download',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({url:analyzed.url,format:selectedFormat(),quality:Number($('quality').value),authorized:true})});if(timer)clearInterval(timer);await poll(job.id);timer=setInterval(()=>poll(job.id),1100);}catch(err){alertMsg(err.message);$('jobMessage').textContent='Não foi possível iniciar.';$('downloadBtn').disabled=false;}});
async function poll(id){try{const job=await api('/api/jobs/'+id);$('jobMessage').textContent=job.message;$('percent').textContent=Math.round(job.progress)+'%';$('progressFill').style.width=job.progress+'%';$('speed').textContent=[job.speed?('Velocidade: '+job.speed):'',job.eta&&job.eta!=='NA'?('Tempo restante: '+job.eta):''].filter(Boolean).join(' · ');if(job.state==='done'){clearInterval(timer);timer=null;$('saveBtn').href='/api/files/'+encodeURIComponent(id);$('saveBtn').classList.remove('hidden');$('downloadBtn').disabled=false;}else if(job.state==='error'){clearInterval(timer);timer=null;alertMsg(job.message);$('downloadBtn').disabled=false;}}catch(err){clearInterval(timer);timer=null;alertMsg(err.message);$('downloadBtn').disabled=false;}}
(async()=>{try{const h=await api('/api/health');$('diagnostic').textContent=h.yt_dlp&&h.ffmpeg?'✓ Motor de download e conversão pronto. Arquivos salvos localmente.':'⚠ Motor incompleto: '+(!h.yt_dlp?'yt-dlp indisponível. ':'')+(!h.ffmpeg?'FFmpeg indisponível. ':'')+'Execute INICIAR_WINDOWS.bat.';}catch(err){$('diagnostic').textContent=err.message;}})();

// V1.3 - Batch queue. Preferences are captured once, then immutable on the server.
let batchTimer = null;
let batchInFlight = false;
function batchUrls(){return $('batchUrls').value.split(/\r?\n/).map(s=>s.trim()).filter(Boolean);}
function countBatch(){const n=batchUrls().length;$('batchCount').textContent=n+' URL'+(n===1?'':'s')+' · máximo de 100 por lote';}
$('batchUrls').addEventListener('input',countBatch);
$('batchPaste').addEventListener('click',async()=>{try{$('batchUrls').value=await navigator.clipboard.readText();countBatch();}catch(e){batchError('Não foi possível colar automaticamente. Use Ctrl+V.');}});
$('batchClear').addEventListener('click',()=>{$('batchUrls').value='';countBatch();});
function batchFormat(){return document.querySelector('input[name="batchFormat"]:checked').value;}
document.querySelectorAll('input[name="batchFormat"]').forEach(el=>el.addEventListener('change',()=>{document.querySelectorAll('.batch-formats .format').forEach(l=>l.classList.toggle('chosen',l.querySelector('input').checked));$('batchQualityWrap').hidden=batchFormat()==='mp3';}));
function batchError(msg){$('batchAlert').textContent=msg;$('batchAlert').classList.remove('hidden');}
function batchClearError(){$('batchAlert').classList.add('hidden');}
$('startBatch').addEventListener('click',async()=>{
  if(batchInFlight)return;
  batchClearError();const urls=batchUrls();
  if(!urls.length)return batchError('Cole pelo menos uma URL, uma por linha.');
  if(urls.length>100)return batchError('Envie até 100 URLs por lote. Você pode criar outros lotes depois.');
  if(!$('batchAuthorized').checked)return batchError('Confirme que tem autorização para baixar o conteúdo.');
  batchInFlight=true;$('startBatch').disabled=true;$('startBatch').textContent='Criando fila...';
  try{
    const batch=await api('/api/batches',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({urls,format:batchFormat(),quality:Number($('batchQuality').value),authorized:true})});
    $('batchProgress').hidden=false;$('batchFolder').textContent='Pasta: downloads / '+batch.folder;
    $('batchList').replaceChildren();
    $('saveAllBtn').classList.add('hidden');
    localStorage.setItem('media_last_batch', batch.id);
    if(batchTimer)clearInterval(batchTimer);
    await pollBatch(batch.id);
    if (!$('batchProgress').dataset.finished) batchTimer=setInterval(()=>pollBatch(batch.id),1200);
  }catch(e){batchError(e.message);}
  finally{batchInFlight=false;$('startBatch').disabled=false;$('startBatch').textContent='Baixar toda a lista, um de cada vez ↓';}
});
async function pollBatch(id){
  try{
    const batch=await api('/api/batches/'+encodeURIComponent(id));
    $('batchProgress').dataset.finished=batch.finished?'yes':'';
    $('batchFolder').textContent='Pasta: downloads / '+batch.folder;
    $('batchStats').textContent=`${batch.completed} de ${batch.total} finalizados · ${batch.succeeded} baixados · ${batch.failed} falhas`;
    const pct=100*(batch.jobs.reduce((a,j)=>a+(j.state==='done'||j.state==='error'?100:Number(j.progress)||0),0)/(batch.total*100));
    $('batchFill').style.width=Math.min(100,Math.max(0,pct))+'%';
    const fragment=document.createDocumentFragment();
    for(const job of batch.jobs){
      const item=document.createElement('div');item.className='batch-item';
      const num=document.createElement('span');num.className='batch-num';num.textContent=String(job.batch_index).padStart(2,'0');item.appendChild(num);
      const detail=document.createElement('div');detail.className='batch-detail';
      const name=document.createElement('strong');name.textContent=job.filename||job.url;detail.appendChild(name);
      const info=document.createElement('small');info.textContent=job.message+(job.state==='running'?` · ${Math.round(job.progress)}%`: '');detail.appendChild(info);item.appendChild(detail);
      const badge=document.createElement('span');badge.className='batch-state '+job.state;
      badge.textContent=({queued:'Na fila',running:'Baixando',done:'Concluído',error:'Falhou'})[job.state]||job.state;
      item.appendChild(badge);       fragment.appendChild(item);
    }
    $('batchList').replaceChildren(fragment);
    const saveAll=$('saveAllBtn');
    if(batch.finished && batch.succeeded > 0){
      saveAll.href='/api/batches/'+encodeURIComponent(id)+'/archive';
      saveAll.textContent='↓ Salvar todos ('+batch.succeeded+' arquivo'+(batch.succeeded===1?'':'s')+') em um ZIP';
      saveAll.classList.remove('hidden');
      $('saveAllHint').textContent=batch.failed ? 'Os '+batch.failed+' vídeo(s) com falha não entram no ZIP. Os arquivos concluídos estão incluídos.' : 'Todos os vídeos foram concluídos. Um clique baixa o pacote completo.';
    }else{
      saveAll.classList.add('hidden');
      $('saveAllHint').textContent=batch.finished ? 'Nenhum arquivo concluído neste lote.' : 'O botão Salvar todos será liberado quando a fila terminar.';
    }
    if(batch.finished && batchTimer){clearInterval(batchTimer);batchTimer=null;}
  }catch(e){if(batchTimer){clearInterval(batchTimer);batchTimer=null;}batchError(e.message);}
}

// Reload the last batch's status after a browser refresh while the server remains running.
(async()=>{
  const id=localStorage.getItem('media_last_batch');if(!id)return;
  try{
    $('batchProgress').hidden=false;
    await pollBatch(id);
    if(!$('batchProgress').dataset.finished)batchTimer=setInterval(()=>pollBatch(id),1200);
  }catch(e){$('batchProgress').hidden=true;}
})();
