@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
title MediaDownloader Local - Windows
echo.
echo  ===========================================
echo       MEDIADOWNLOADER LOCAL - V1.6
echo  ===========================================
echo.
if exist ".venv\Scripts\python.exe" goto install
where py >nul 2>nul
if not errorlevel 1 (
    py -3 -m venv ".venv"
    goto created
)
where python >nul 2>nul
if not errorlevel 1 (
    python -m venv ".venv"
    goto created
)
echo [ERRO] Python nao encontrado. Instale Python 3.11 ou 3.12 no python.org.
echo Marque a opcao "Add python.exe to PATH" na instalacao.
pause
exit /b 1
:created
if not exist ".venv\Scripts\python.exe" (
    echo [ERRO] Nao foi possivel criar o ambiente Python.
    pause
    exit /b 1
)
:install
echo Verificando dependencias... requer internet na primeira execucao.
".venv\Scripts\python.exe" -m pip install --disable-pip-version-check -r "requirements.txt"
if errorlevel 1 (
    echo.
    echo [ERRO] Nao foi possivel instalar as dependencias.
    echo Verifique a conexao com a internet e tente novamente.
    pause
    exit /b 1
)
echo.
echo Abrindo o sistema em http://127.0.0.1:8765
".venv\Scripts\python.exe" "server.py"
if errorlevel 1 (
    echo.
    echo [ERRO] O servidor foi encerrado com erro.
    pause
)
endlocal
