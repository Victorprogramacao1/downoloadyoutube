MEDIADOWNLOADER LOCAL - Versao 1.1
=================================

INSTALACAO (Windows 10/11)
1. Instale o Python 3.11 ou 3.12 de https://www.python.org/downloads/windows/
   Marque "Add python.exe to PATH".
2. Extraia este ZIP inteiro para uma pasta. Nao execute dentro do ZIP.
3. Clique duas vezes em INICIAR_WINDOWS.bat.
4. Na primeira vez, o Windows precisa de internet para baixar dependencias Python
   e o executavel FFmpeg (incluso no pacote imageio-ffmpeg).
5. O navegador abre http://127.0.0.1:8765 automaticamente.
6. Cole um link de video publico do YouTube que voce tenha permissao para baixar.
7. Clique em Analisar, escolha MP4 ou MP3, confirme a autorizacao e inicie.
8. Ao concluir, clique em Salvar arquivo. Os arquivos permanecem em downloads/.

O QUE FUNCIONA
- Interface em portugues, responsiva e tema escuro.
- Analise real de metadados com yt-dlp.
- Download MP4 em 360p, 720p ou 1080p, conforme formatos disponiveis.
- Opcao 1080p: converte para MP4 H.264/AAC e limita dimensoes a Full HD
  (1920x1080 horizontal ou 1080x1920 vertical), sem distorcer a imagem.
- Conversao real MP3 com FFmpeg.
- Progresso consultado em tempo real.
- Arquivos ficam localmente no computador.
- Fila de ate 2 tarefas simultaneas, ate 4 pendentes.
- Servidor escuta somente no proprio computador (127.0.0.1).

LIMITACOES
- Baixe apenas material de sua autoria ou com permissao/licenca adequadas.
- Nao remove DRM, nao contorna login/assinatura, conteudos privados ou bloqueios.
- YouTube pode modificar o site e quebrar extracao. Use ATUALIZAR_MOTOR.bat.
- O download depende da rede, formatos disponiveis e disponibilidade do video.
- Playlists e lives em andamento nao sao suportadas.
- Algumas fontes nao oferecem MP4 na resolucao escolhida ou falham na conversao.
- Requer espaco livre em disco; um video longo pode ocupar centenas de MB.
- O modo 1080p exige uma fonte 1080p e recodifica o video e pode demorar bastante, dependendo do PC.
- Se o original tiver resolucao menor que 1080p, ele nao cria detalhes novos.
- Para qualidade EXATAMENTE 1080p, o video original precisa oferecer 1080p.
- Nao execute como administrador; nao exponha a porta na internet.
- A lista de tarefas fica em memoria; arquivos continuam na pasta downloads/.

DIAGNOSTICO
- http://127.0.0.1:8765/api/health confirma as dependencias.
- Se o navegador nao abrir automaticamente, digite esse endereco manualmente.
- Para encerrar, pressione Ctrl+C na janela preta do servidor.
- Se a porta 8765 estiver ocupada, encerre outra copia do aplicativo.

ARQUIVOS
server.py              servidor e motor de processamento
web/index.html         interface
web/style.css          estilos
web/app.js             interacoes do navegador
INICIAR_WINDOWS.bat    instalador/iniciador
ATUALIZAR_MOTOR.bat    atualizador yt-dlp
ABRIR_PASTA_DOWNLOADS.bat  acesso aos arquivos
requirements.txt       dependencias

Este aplicativo nao e afiliado ao YouTube nem ao YTDown.

V1.2: qualidade 1080p selecionada por padrao; exige stream com 1080 linhas; MP4 H.264/AAC; confere as dimensoes finais; falha claramente se 1080p nao estiver disponivel.


NOVIDADE V1.3 - DOWNLOAD EM CADEIA
=================================
1. Abra a interface local e procure o painel "Download em cadeia".
2. Cole 1 a 100 URLs do YouTube, uma por linha.
3. Selecione MP4 e 1080p (ou outra configuracao) uma unica vez.
4. Confirme a permissao e clique em "Baixar toda a lista".
5. Todos os itens entram na fila, em ordem, e sao processados de forma
   SEQUENCIAL (apenas um download por vez).
6. Cada lote ganha uma pasta propria, dentro de downloads/Lote_DATA_ID.
   Os nomes possuem prefixos 001, 002, ... na ordem original.
7. Se uma URL falhar, as URLs seguintes continuam normalmente.
8. Atualizar a aba recupera o ultimo lote enquanto o servidor estiver aberto.
9. Nao feche a janela preta do servidor ate terminar todos os downloads.
10. A opcao 1080p exige uma fonte com 1080 linhas; nao substitui por 720p.
11. Todos os arquivos gerados ficam salvos automaticamente no computador;
    o link 'Salvar' por item e opcional.

AVISO: o estado de tarefas em andamento e mantido apenas na memoria durante
esta execucao. Fechar o servidor interrompe a fila; arquivos ja concluidos
permanecem no disco.

V1.6: modo rapido prioriza 1080p H.264/AAC e permite 4 fragmentos por video; fila continua sequencial.
