import unittest
from pathlib import Path
from unittest.mock import patch
import server

class FastModeTest(unittest.TestCase):
    def test_1080_prefers_native_avc_and_uses_four_fragments(self):
        jid = 'fast_mode_fake'
        server.JOBS[jid] = {'id': jid, 'url':'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
                            'format':'mp4', 'quality':1080, 'batch_index':1,
                            'batch_folder':'Lote_TESTE_FAST','state':'queued', 'progress':0,
                            'filename':None}
        captured=[]
        def fake_popen(cmd, **kwargs):
            captured.extend(cmd)
            raise RuntimeError('captured')
        try:
            with patch.object(server,'ffmpeg_path',return_value='ffmpeg'), patch.object(server.subprocess,'Popen',side_effect=fake_popen):
                server.run_job(jid)
            self.assertEqual(server.JOBS[jid]['state'],'error')
            self.assertEqual(captured[captured.index('--concurrent-fragments')+1], '4')
            selector=captured[captured.index('-f')+1]
            self.assertTrue(selector.startswith('bv[height=1080][ext=mp4][vcodec^=avc1]+ba[ext=m4a]/'))
            self.assertIn('bv[height=1080]+ba',selector)
        finally:
            server.JOBS.pop(jid,None)
            import shutil
            shutil.rmtree(server.DOWNLOADS/'Lote_TESTE_FAST', ignore_errors=True)

if __name__=='__main__':unittest.main()
