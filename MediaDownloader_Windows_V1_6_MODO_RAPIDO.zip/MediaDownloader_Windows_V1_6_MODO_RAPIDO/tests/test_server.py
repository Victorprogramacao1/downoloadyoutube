import unittest
from fastapi.testclient import TestClient
import server

class TestMediaDownloader(unittest.TestCase):
    def setUp(self): self.client=TestClient(server.app)
    def test_home_and_health(self):
        self.assertEqual(self.client.get('/').status_code,200)
        self.assertTrue(self.client.get('/api/health').json()['local'])
    def test_valid_url(self):
        ident='dQw4w9WgXcQ'
        for url in [f'https://www.youtube.com/watch?v={ident}',f'https://youtu.be/{ident}',f'https://www.youtube.com/shorts/{ident}']:
            self.assertEqual(server.validate_url(url),f'https://www.youtube.com/watch?v={ident}')
    def test_reject_urls(self):
        for url in ['http://youtube.com/watch?v=dQw4w9WgXcQ','https://youtube.com.evil.net/watch?v=dQw4w9WgXcQ','https://127.0.0.1/x','https://www.youtube.com/','file:///etc/passwd','https://www.youtube.com/watch?v=bad','https://www.youtube.com:443/watch?v=dQw4w9WgXcQ']:
            with self.assertRaises(ValueError, msg=url): server.validate_url(url)
    def test_requires_authorization(self):
        res=self.client.post('/api/download',json={'url':'https://youtu.be/dQw4w9WgXcQ','authorized':False})
        self.assertEqual(res.status_code,400)
    def test_no_unknown_file(self):
        self.assertEqual(self.client.get('/api/files/nothing').status_code,404)
        self.assertEqual(self.client.get('/api/jobs/nothing').status_code,404)

if __name__=='__main__': unittest.main()
