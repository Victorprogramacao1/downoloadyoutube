import io
import tempfile
import unittest
import zipfile
from pathlib import Path
from fastapi.testclient import TestClient
import server

class BatchArchiveTest(unittest.TestCase):
    def test_archive_gating_and_content(self):
        original = server.DOWNLOADS
        with tempfile.TemporaryDirectory() as temporary:
            server.DOWNLOADS = Path(temporary)
            folder = server.DOWNLOADS / 'Lote_TESTE_123456'
            folder.mkdir()
            (folder / '001 - Um.mp4').write_bytes(b'conteudo-um')
            (folder / '002 - Dois.mp4').write_bytes(b'conteudo-dois')
            bid = 'batch_fake_test'
            server.BATCHES[bid] = {'id':bid,'ids':['job_fake_1','job_fake_2'],'folder':folder.name,'format':'mp4','quality':1080}
            for idx, name in enumerate(['001 - Um.mp4', '002 - Dois.mp4'], 1):
                server.JOBS[f'job_fake_{idx}'] = {'state':'done' if idx == 1 else 'running','batch_index':idx,'filename':name}
            client = TestClient(server.app)
            try:
                self.assertEqual(client.get(f'/api/batches/{bid}/archive').status_code, 409)
                server.JOBS['job_fake_2']['state'] = 'done'
                response = client.get(f'/api/batches/{bid}/archive')
                self.assertEqual(response.status_code, 200)
                self.assertEqual(response.headers['content-type'],'application/zip')
                with zipfile.ZipFile(io.BytesIO(response.content)) as archive:
                    self.assertEqual(archive.namelist(), ['001 - Um.mp4', '002 - Dois.mp4'])
                    self.assertEqual(archive.read('001 - Um.mp4'),b'conteudo-um')
                self.assertTrue((server.DOWNLOADS / (folder.name+'.zip')).is_file())
                self.assertTrue((folder/'001 - Um.mp4').is_file())
            finally:
                server.BATCHES.pop(bid,None)
                server.JOBS.pop('job_fake_1',None)
                server.JOBS.pop('job_fake_2',None)
                server.DOWNLOADS=original

if __name__ == '__main__': unittest.main()
