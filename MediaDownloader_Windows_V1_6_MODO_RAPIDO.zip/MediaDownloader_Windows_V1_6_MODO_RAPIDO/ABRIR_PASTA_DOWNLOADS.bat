@echo off
cd /d "%~dp0"
if not exist "downloads" mkdir "downloads"
start "" "%~dp0downloads"
